Extract Qt sources here.
