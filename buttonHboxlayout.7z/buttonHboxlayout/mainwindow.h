#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QtWidgets"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    void contextMenuRequested(const QPoint& point);
    void ClickInsertButtonTrace();
    void ClickInsertButtonData();
    void ClickInsertButtonLog();
    void ClickRemove();

private:
    Ui::MainWindow *ui;
    QMenu *ShowMenu;
    QLayout *layout;
    QPushButton *button[100];
    QPushButton *Button_1;
    QHBoxLayout *H_layout;
    QVBoxLayout *V_layout;
    QVBoxLayout *V1_layout;
    QCheckBox *Checkbox[100];
    QAction *InsertTraceWindow;
    QAction *InsertDataWindow;
    QAction *InsertLoggingWindow;
    QAction *Remove;
};

#endif // MAINWINDOW_H
