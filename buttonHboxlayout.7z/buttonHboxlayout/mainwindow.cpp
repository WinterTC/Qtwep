#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ShowMenu = new QMenu(this);
   // setContextMenuPolicy(Qt::CustomContextMenu);
    this->setContextMenuPolicy(Qt::CustomContextMenu);

    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    Remove = ShowMenu->addAction("Remove");

    connect(this,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));

    Button_1 = new QPushButton("One");
//    Button_1->setFixedHeight(50);
//    Button_1->setFixedWidth(70);
    qDebug()<<Button_1->pos();
    H_layout = new QHBoxLayout(this);
    H_layout->addWidget(Button_1);

    QCheckBox *Checkbox1 = new QCheckBox(this);
    QCheckBox *Checkbox2 = new QCheckBox(this);
    QCheckBox *Checkbox3 = new QCheckBox(this);

    Checkbox1->setChecked(true);
    Checkbox2->setChecked(true);
    Checkbox3->setChecked(true);


    QPushButton *button2 = new QPushButton("Trace");
//    button2->setFixedHeight(50);
//    button2->setFixedWidth(70);
    QPushButton *button3 = new QPushButton("Data");
//    button3->setFixedHeight(50);
//    button3->setFixedWidth(70);
    QPushButton *button4 = new QPushButton("Logging");
//    button4->setFixedHeight(50);
//    button4->setFixedWidth(70);

    V_layout = new QVBoxLayout(this);
    V_layout->addWidget(button2);
    V_layout->addWidget(button3);
    V_layout->addWidget(button4);

    V1_layout = new QVBoxLayout(this);
    V1_layout->addWidget(Checkbox1);
    V1_layout->addWidget(Checkbox2);
    V1_layout->addWidget(Checkbox3);


    ui->widget->setLayout(V_layout);

    ui->widget_button_1->setLayout(H_layout);

    ui->widget_2->setLayout(V1_layout);

    connect(Checkbox1,SIGNAL(clicked(bool)),button2,SLOT(setEnabled(bool)));
    connect(Checkbox2,SIGNAL(clicked(bool)),button3,SLOT(setEnabled(bool)));
    connect(Checkbox3,SIGNAL(clicked(bool)),button4,SLOT(setEnabled(bool)));

    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));
    connect(Remove,SIGNAL(triggered()),this,SLOT(ClickRemove()));

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::contextMenuRequested(const QPoint& point)
{
    ShowMenu->popup(mapToGlobal(point));
}

void MainWindow::ClickInsertButtonTrace()
{
    static int i =0;
    button[i] = new QPushButton(tr("Trace %1").arg(i+1));
//    button[i]->setFixedHeight(50);
//    button[i]->setFixedWidth(70);
    V_layout->addWidget(button[i]);
    ui->widget->setLayout(V_layout);
    qDebug() << button[i]->cursor().pos();
    qDebug() << button[i]->mapFromGlobal(button[i]->cursor().pos());

    Checkbox[i] = new QCheckBox(tr("").arg(i+1));
    Checkbox[i]->setChecked(true);
    V1_layout->addWidget(Checkbox[i]);
    ui->widget_2->setLayout(V1_layout);

    connect(Checkbox[i],SIGNAL(clicked(bool)),button[i],SLOT(setEnabled(bool)));
    i++;
}

void MainWindow::ClickInsertButtonData()
{
    static int i =0;
    button[i] = new QPushButton(tr("Data %1").arg(i+1));
//    button[i]->setFixedHeight(50);
//    button[i]->setFixedWidth(70);
    V_layout->addWidget(button[i]);
    ui->widget->setLayout(V_layout);

    Checkbox[i] = new QCheckBox(tr("").arg(i+1));
    Checkbox[i]->setChecked(true);
    V1_layout->addWidget(Checkbox[i]);
    ui->widget_2->setLayout(V1_layout);

    connect(Checkbox[i],SIGNAL(clicked(bool)),button[i],SLOT(setEnabled(bool)));
    i++;
}

void MainWindow::ClickInsertButtonLog()
{
    static int i =0;
    button[i] = new QPushButton(tr("Logging %1").arg(i+1));
//    button[i]->setFixedHeight(50);
//    button[i]->setFixedWidth(70);
    V_layout->addWidget(button[i]);
    ui->widget->setLayout(V_layout);

    Checkbox[i] = new QCheckBox(tr("").arg(i+1));
    Checkbox[i]->setChecked(true);
    V1_layout->addWidget(Checkbox[i]);
    ui->widget_2->setLayout(V1_layout);

    connect(Checkbox[i],SIGNAL(clicked(bool)),button[i],SLOT(setEnabled(bool)));
    i++;
}

void MainWindow::ClickRemove()
{
    static int i =0;
    V_layout->removeWidget(button[i]);
    V1_layout->removeWidget(Checkbox[i]);
    i++;
}
