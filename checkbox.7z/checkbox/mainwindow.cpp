#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QWidget *widget = new QWidget(this);

    V1_box = new QVBoxLayout;
    Button1 = new QPushButton("Bt_1");
    qDebug()<<Button1->cursor().pos();
    qDebug()<<Button1->mapFromGlobal(Button1->cursor().pos());
    //qDebug()<<Button1->pos();
    V1_box->addWidget(Button1);

    V2_box = new QVBoxLayout;
    Button2 = new QPushButton("Bt_2");
    qDebug()<<Button2->pos();
    Button3 = new QPushButton("Bt_3");
    Button4 = new QPushButton("Bt_4");
    V2_box->addWidget(Button2);
    V2_box->addWidget(Button3);
    V2_box->addWidget(Button4);

    QHBoxLayout *layout = new QHBoxLayout;
    layout->addLayout(V1_box);
    layout->addLayout(V2_box);

    widget->setLayout(layout);
    setCentralWidget(widget);

}

MainWindow::~MainWindow()
{
    delete ui;
}
